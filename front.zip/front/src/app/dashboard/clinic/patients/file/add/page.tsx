'use client'
import { useState, useEffect } from 'react';
import { TextField, Button, Container, Typography, Box } from '@mui/material';
import { useSearchParams ,useRouter} from 'next/navigation';
import DashboardLayout from '@/app/dashboard/components/DashboardLayout';
import api from '@/app/utils/api';
import { getClinicProperty } from '@/app/utils/helper';

export default function PatientForm() {
    const router = useRouter();
    const searchParams = useSearchParams();
    const patientId = searchParams.get('id');

    useEffect(() => {
        const fetchFileData = async () => {
            try {
                const response = await api.get(`/patients/file/${patientId}`);
                
                if (response.data) {
                    setFormData(prevData => ({
                        ...prevData,
                        ...response.data
                    }));
                }
            } catch (error) {
                console.error('Error fetching file data:', error);
            }
        };
    
        fetchFileData();
    }, []);
    const [formData, setFormData] = useState({
        childrenInfo: '',
        childOrder: '',
        parentsJob: '',
        birthDiseases: '',
        associatedProblems: '',
        surgeryHistory: '',
        medicationHistory: '',
        assistiveDevices: '',
        rehabilitationHistory: '',
        initialAssessmentResults: '',
        treatmentGoals: ''
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        const clinic= getClinicProperty('id')
        try {
            const data={ ...formData,clinic, patient: patientId }
            const response = await api.post('/patients/file',data);
            if (response.status==200) {
                alert('اطلاعات با موفقیت ارسال شد');
                router.push('/dashboard/clinic/patients');
            }
        } catch (error) {
            console.error('Error submitting form:', error);
        }
    };

    return (
        <DashboardLayout>

        <Container maxWidth="sm">
            <Typography variant="h5" gutterBottom>فرم اطلاعات بیمار</Typography>
            <div >
            <TextField fullWidth   label="اطلاعات فرزندان" name="childrenInfo" placeholder="مثلاً: یک پسر و یک دختر" value={formData.childrenInfo} onChange={handleChange} />

                <Box display="flex" gap={2} marginTop={2}>
                    <TextField fullWidth   label="ترتیب فرزند" name="childOrder" placeholder="مثلاً: ۲" type="number" value={formData.childOrder} onChange={handleChange} />
                    <TextField fullWidth label="شغل والدین" name="parentsJob" placeholder="مثلاً: معلم و مهندس" value={formData.parentsJob} onChange={handleChange} />
                </Box>
                 <TextField fullWidth  margin="normal"   label="بیماری‌های کودک هنگام تولد" name="birthDiseases" placeholder="مثلا تشنج ، زردی ، اسهال ، ضربه به سر ، ُ بیماری های متابولیک" value={formData.birthDiseases} onChange={handleChange} />
                 <TextField fullWidth  margin="normal"   label="مشکلات همراه کودک" name="associatedProblems" placeholder="نابینایی ، عقب ماندگی ، مشکلات گفتاری ، مشکلات تغذیه ای ، مشکلات قلبی " value={formData.associatedProblems} onChange={handleChange} />
                 <TextField fullWidth  margin="normal"   label="سابقه جراحی" name="surgeryHistory" placeholder="" value={formData.surgeryHistory} onChange={handleChange} />
                 <TextField fullWidth  margin="normal"   label="سابقه مصرف دارویی" name="medicationHistory" placeholder="" value={formData.medicationHistory} onChange={handleChange} />
                 <TextField fullWidth  margin="normal"   label="از وسایل کمکی استفاده میکند؟" name="assistiveDevices" placeholder="" value={formData.assistiveDevices} onChange={handleChange} />

                <TextField fullWidth multiline rows={3} margin="normal" label="تاریخچه توانبخشی دریافت شده" name="rehabilitationHistory" placeholder="" value={formData.rehabilitationHistory} onChange={handleChange} />
                <TextField fullWidth multiline rows={3} margin="normal" label="نتایج ارزیابی اولیه" name="initialAssessmentResults" placeholder="توضیحات مربوط به ارزیابی اولیه" value={formData.initialAssessmentResults} onChange={handleChange} />
                <TextField fullWidth multiline rows={3} margin="normal" label="اهداف درمانی" name="treatmentGoals" placeholder="توضیحی درباره اهداف درمانی" value={formData.treatmentGoals} onChange={handleChange} />
                <Box display="flex" justifyContent="space-between" mt={2}>
                    <Button variant="contained" color="secondary" onClick={() => router.back()}>بازگشت</Button>
                    <Button type="submit" variant="contained" onClick={handleSubmit} color="primary">ارسال</Button>
                </Box>
            </div>
        </Container>
        </DashboardLayout>
    );
}
