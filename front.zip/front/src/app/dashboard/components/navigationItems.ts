export const navigationItems = [
    { label: 'داشبورد', path: '/dashboard', icon: '🏠' },
    { label: 'بیماران', path: '/dashboard/clinic/patients', icon: '⚙️' },
    { label: 'تراپیست ها', path: '/dashboard/clinic/thrapists', icon: '👤' },
];
