import React from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { TextField, Button, Container, Typography } from '@mui/material';
import axios from 'axios';

const AddReportForm = () => {
  const formik = useFormik({
    initialValues: {
      patientId: '',
      reportText: '',
    },
    validationSchema: Yup.object({
      patientId: Yup.string()
        .required('Patient ID is required')
        .min(24, 'Invalid Patient ID'), // فرض بر این است که patientId یک شناسه 24 کاراکتری MongoDB است
      reportText: Yup.string()
        .required('Report text is required')
        .min(10, 'Report text should be at least 10 characters long'),
    }),
    onSubmit: async (values) => {
      try {
        const response = await axios.post('/api/reports', values);
        console.log('Report created successfully', response.data);
      } catch (error) {
        console.error('Error creating report:', error);
      }
    },
  });

  return (
    <Container maxWidth="sm">
      <Typography variant="h4" gutterBottom>
        Add Report
      </Typography>
      <form onSubmit={formik.handleSubmit}>
        <TextField
          fullWidth
          label="Patient ID"
          name="patientId"
          value={formik.values.patientId}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.patientId && Boolean(formik.errors.patientId)}
          helperText={formik.touched.patientId && formik.errors.patientId}
          margin="normal"
        />
        <TextField
          fullWidth
          label="Report Text"
          name="reportText"
          multiline
          rows={4}
          value={formik.values.reportText}
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          error={formik.touched.reportText && Boolean(formik.errors.reportText)}
          helperText={formik.touched.reportText && formik.errors.reportText}
          margin="normal"
        />
        <Button
          fullWidth
          variant="contained"
          color="primary"
          type="submit"
          disabled={!formik.isValid || formik.isSubmitting}
        >
          Submit Report
        </Button>
      </form>
    </Container>
  );
};

export default AddReportForm;
